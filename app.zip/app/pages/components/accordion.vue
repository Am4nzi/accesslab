<template>
  <div>
    <h1>Accordion</h1>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped></style>
