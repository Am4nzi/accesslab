<template>
  <div>
    <h1>AccessLab</h1>
    <p>
      Welcome to AccessLab, your resource for accessibility tools and
      information.
    </p>
  </div>
</template>

<script setup lang="ts">
// Page meta information (optional)
definePageMeta({
  title: "Home",
});
</script>
